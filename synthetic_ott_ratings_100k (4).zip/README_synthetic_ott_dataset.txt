Synthetic OTT Ratings Dataset (100,000 rows)

IMPORTANT:
This is a simulated dataset generated for experimentation. It is NOT real data
from Netflix or any other streaming platform. Cite and describe it as synthetic
data if used in a research project.

Rows: 100,000
Columns:
- user_id: anonymized simulated user identifier
- content_id: simulated content identifier
- genre: content genre
- watch_time_minutes: simulated viewing duration
- completion_percentage: simulated percentage of content watched
- previous_rating: simulated earlier rating, on a 1-5 scale
- sessions_last_30_days: simulated recent activity count
- target_rating: simulated rating to predict, on a 1-5 scale

Suggested experiment:
Use genre as a categorical feature (one-hot encode it), and use the other
predictor columns except target_rating as X. Use target_rating as y.
Compare Linear Regression and a Neural Network on the same train/test split.
Report MAE, RMSE, R-squared, and training time. Fit preprocessing only on the
training data. The data-generation process creates relationships between some
features and target_rating, so it is useful for code testing, but performance
results should not be presented as evidence about real OTT users.
